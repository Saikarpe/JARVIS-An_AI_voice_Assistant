from groq import Groq # Importing the Groq library to use
from json import load, dump # Importing functions to reao
import datetime # Importing the datetime module for real-
from dotenv import dotenv_values 

env_vars = dotenv_values(".env")

Username = env_vars.get("Username")
Assistantname = env_vars.get("Assistantname")
GroqAPIKey = env_vars.get("GroqAPIKey")

client = Groq(api_key=GroqAPIKey)
messages = []
# Define a system message that provides context to the AI
System = f"""Hello, I am {Username}, You are a very accurate and advanced AI chatbot named {Assistantname} which also has real-time up-to-date information from the internet.
*** Do not tell time until I ask, do not talk too much, just answer the question.***
*** Reply in only English, even if the question is in Hindi, reply in English.***
*** Do not provide notes in the output, just answer the question and never mention your training data. ***
"""
SystemChatBot =[
    {"role": "system", "content": System}
]
try :
    with open(r"Data\ Chatlog.json","r") as f:
        messages = load(f)
except FileNotFoundError:
    with open(r"Data\ Chatlog.json","w") as f:
        dump([], f)

def RealtimeInformation():
    current_date_time = datetime.datetime.now()
    day = current_date_time.strftime("%A")
    date = current_date_time.strftime("%d")
    month = current_date_time.strftime("%B")
    year = current_date_time.strftime("%Y")
    hour = current_date_time.strftime("%H")
    minute = current_date_time.strftime("%M")
    second = current_date_time.strftime("%S")

    data = f"Please use this real time information if needed:\n"
    data += f"Day : {day}\nDate : {date}\nMonth : {month}\nYear : {year}\n"
    data += f"Time : {hour} hours :{minute} minutes : {second} seconds.\n"
    return data

def AnswerModifier (Answer):
    lines = Answer.split('\n') # Split the response into lines.
    non_empty_lines = [line for line in lines if line.strip()] # Remove empty lines.
    modified_answer = '\n'.join(non_empty_lines) # Join the cleaned lines back together.
    return modified_answer

# Main chatbot function to handle user queries.

def ChatBot(Query):
    """ This function sends the user's query to the chatbot and returns the AI's response."""
    
    try:
        with open(r"Data\ ChatLog.json", "r") as f:

            messages = load(f)
        
        messages.append({"role": "user", "content": f" {Query}"})
        completion = client.chat.completions.create(
            model="llama3-70b-8192", # Specify the AI model to use.
            messages=SystemChatBot + [{"role": "system", "content": RealtimeInformation()}] + messages,
            max_tokens=1024, # Limit the maximum tokens in the response.
            temperature=0.7, # Adjust response randomness (higher means more random).
            top_p=1, # Use nucleus sampling to control diversity.
            stream=True, #Enable streaming response.
            stop=None #Allow the model to determine when to stop.
        )

        Answer = ""# Initialize an empty string to store the AI's response.
        
        for chunk in completion:
            if chunk.choices[0].delta.content: #Check if there's content in the current chunk.
                Answer += chunk.choices[0].delta.content # Append the content to the answer.

        Answer = Answer.replace("</s>", "") # Clean up any unwanted tokens from the response.
        
        messages.append({"role": "assistant", "content": Answer})
        
        with open(r"Data\ ChatLog.json", "w") as f:
            dump(messages, f, indent=4)
        return AnswerModifier (Answer=Answer)

    except Exception as e:

# Handle errors by printing the exception and resetting the
        print(f"Error: {e}")
        with open(r"Data\ ChatLog.json", "w") as f:
            dump([], f, indent=4)
        return ChatBot (Query) # Retry the query after resetting the

#Main program entry point.

if __name__== "__main__":
    while True:
        user_input = input("Enter Your Question: ")
        print(ChatBot(user_input)) 