
    def SpeechRecogText(self):